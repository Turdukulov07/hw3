package com.company;

import java.util.PrimitiveIterator;

public class Main {

    public static void main(String[] args) {
        int var = 25 ;
        System.out.println("Привет мир!");
        System.out.println(var);

        int a;
        a = 75;
        int b = (a + 10)*2;

        String result = "Мой рост" + "-" + b;
        System.out.println(result);
        final String PI = "Привет";
        System.out.println(PI);




    }
}
